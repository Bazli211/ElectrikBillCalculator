package com.example.electricitybillestimation;

import android.os.Bundle;
import android.sax.Element;
import android.text.method.LinkMovementMethod;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import androidx.appcompat.widget.Toolbar;


public class About extends AppCompatActivity {
    TextView textView6,textView7;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);

        textView6=findViewById(R.id.textView6);
        textView7=findViewById(R.id.textView7);

    textView6.setMovementMethod(LinkMovementMethod.getInstance());
    textView7.setMovementMethod(LinkMovementMethod.getInstance());
    }
}
