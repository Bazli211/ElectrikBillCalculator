package com.example.electricitybillestimation;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    Button button;
    Button About;
    EditText etNumber1, etNumber2;
    TextView textView2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button = findViewById(R.id.button);
        etNumber1 = findViewById(R.id.etNumber1);
        etNumber2 = findViewById(R.id.etNumber2);
        textView2 = findViewById(R.id.textView2);
        About = findViewById(R.id.About);
        DecimalFormat format = new DecimalFormat("0.00");

        button.setOnClickListener(this);
        About.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, About.class);
                startActivity(intent);
            }
        });

        Toolbar myToolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);
    }

    @Override
    public void onClick(View v) {
        if (v == button) {
            String number2 = etNumber2.getText().toString();
            String number1 = etNumber1.getText().toString();

            double consumption;
            double rebatePercentage;
            double totalCharges = 0;
            double finalCost = 0;
            try {
                consumption = Double.parseDouble(number1);
                rebatePercentage = Double.parseDouble(number2);
                totalCharges = 0;
                if (consumption <= 200) {
                    totalCharges = consumption * 0.218;
                } else if (consumption <= 300) {
                    totalCharges = 200 * 0.218 + (consumption - 200) * 0.334;
                } else if (consumption <= 600) {
                    totalCharges = 200 * 0.218 + 100 * 0.334 + (consumption - 300) * 0.516;
                } else {
                    totalCharges = 200 * 0.218 + 100 * 0.334 + 300 * 0.516 + (consumption - 600) * 0.546;
                }

                double rebateAmount = totalCharges * (rebatePercentage);
                finalCost = totalCharges - rebateAmount;

            } catch (NumberFormatException nfe) {
                Toast.makeText(this, "Please enter numbers in the input field", Toast.LENGTH_SHORT).show();
            } catch (Exception exception) {
                Toast.makeText(this, "Please enter numbers in the input field", Toast.LENGTH_SHORT).show();
            }
            textView2.setText("Total : RM " + finalCost);

        }
    }
}